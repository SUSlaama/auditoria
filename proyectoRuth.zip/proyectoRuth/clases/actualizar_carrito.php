<?php /*
require '../config/config.php';
require '../config/database.php';

if (isset($_POST['action'])){

    $action = $_POST['action'];
    $id = isset($_POST['id'])

}*/
?>